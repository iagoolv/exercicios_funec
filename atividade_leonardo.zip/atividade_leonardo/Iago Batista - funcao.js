function calcular(n1, n2){
    return Number(n1) + Number(n2);
}